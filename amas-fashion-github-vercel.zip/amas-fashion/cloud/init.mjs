import { openStore } from './commerce.mjs';
import { requireLinkedCloud } from './cli-preflight.mjs';
await requireLinkedCloud();let store;
try{store=await openStore(undefined,{initialize:true});console.log('Cloud database schema initialized. Existing records were preserved.');}finally{store?.close()}
