import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
test('cloud owner setup reports non-interactive usage cleanly without an unhandled rejection',()=>{
 const command=spawnSync(process.execPath,[fileURLToPath(new URL('../cloud/setup-admin.mjs',import.meta.url))],{encoding:'utf8',env:{PATH:process.env.PATH}});
 assert.equal(command.status,1);
 assert.match(command.stderr,/Run this command in your own interactive Terminal/);
 assert.doesNotMatch(command.stderr,/at main|TypeError|UnhandledPromiseRejection/);
});
