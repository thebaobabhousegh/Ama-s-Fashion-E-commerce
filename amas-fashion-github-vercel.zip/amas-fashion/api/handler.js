import { openStore } from '../cloud/commerce.mjs';
import { createHandler,configuration } from '../cloud/handler.mjs';
export const config={api:{bodyParser:false}};
export default async function handler(req,res){
 let store;
 try{
  const domains=[process.env.VERCEL_URL,process.env.VERCEL_PROJECT_PRODUCTION_URL];if(process.env.PUBLIC_ORIGIN)domains.push(new URL(process.env.PUBLIC_ORIGIN).host);
  const host=req.headers.host;
  if(!host||!domains.includes(host)){res.writeHead(400,{'Content-Type':'application/json'});return res.end(JSON.stringify({error:'Invalid deployment host.'}))}
  const origin='https://'+host;
  const url=new URL(req.url,origin);const path=url.searchParams.get('__path');if(path!==null){url.searchParams.delete('__path');req.url='/api/'+path+(url.search?'?'+url.searchParams.toString():'')}
  // Vercel owns this header on deployed Functions. Never use caller-supplied
  // forwarding headers when running the local server.
  req.cloudClientIp=req.headers['x-vercel-forwarded-for']?.split(',')[0].trim()||req.socket.remoteAddress||'unknown';
  store=await openStore();
  const serve=await createHandler(store,configuration({...process.env,NODE_ENV:'production',PUBLIC_ORIGIN:origin}));
  await serve(req,res);
 }catch{if(!res.headersSent){res.writeHead(503,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({error:'Store setup is incomplete. Check the cloud database configuration and schema.'}))}else res.end()}
 finally{store?.close()}
}
