import { DatabaseSync } from 'node:sqlite';
import { randomBytes, createHash } from 'node:crypto';
import { managedImagePath } from './images.mjs';
import { StoreError } from './errors.mjs';
export { StoreError } from './errors.mjs';
export const digest=v=>createHash('sha256').update(v).digest('hex');
export function openStore(path=':memory:'){
 const db=new DatabaseSync(path);db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
 db.exec(`CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,color TEXT NOT NULL,description TEXT NOT NULL,image TEXT NOT NULL,price_minor INTEGER NOT NULL CHECK(price_minor>0),active INTEGER NOT NULL DEFAULT 0 CHECK(active IN(0,1)));
 CREATE TABLE IF NOT EXISTS variants(product_id INTEGER NOT NULL REFERENCES products(id),size TEXT NOT NULL,stock INTEGER NOT NULL CHECK(stock>=0),PRIMARY KEY(product_id,size));
 CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,token_hash TEXT NOT NULL,idempotency_key TEXT UNIQUE NOT NULL,request_hash TEXT NOT NULL,customer_json TEXT NOT NULL,items_json TEXT NOT NULL,subtotal_minor INTEGER NOT NULL,shipping_minor INTEGER NOT NULL,total_minor INTEGER NOT NULL,currency TEXT NOT NULL DEFAULT 'GHS',status TEXT NOT NULL CHECK(status IN('pending_payment','paid','processing','shipped','completed','expired','payment_review','cancelled','refunded')),shipping_zone TEXT NOT NULL,payment_url TEXT,payment_event_id TEXT UNIQUE,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS admin_sessions(token_hash TEXT PRIMARY KEY,expires_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,action TEXT NOT NULL,resource_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE INDEX IF NOT EXISTS orders_created ON orders(created_at);
 PRAGMA user_version=1;`);
 const transaction=fn=>{db.exec('BEGIN IMMEDIATE');try{const r=fn();db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}};
 function catalogue(includeInactive=false){return db.prepare(`SELECT * FROM products ${includeInactive?'':'WHERE active=1'} ORDER BY id`).all().map(p=>({...p,active:!!p.active,price:p.price_minor/100,variants:db.prepare('SELECT size,stock FROM variants WHERE product_id=? ORDER BY CASE size WHEN \'XS\' THEN 0 WHEN \'S\' THEN 1 WHEN \'M\' THEN 2 WHEN \'L\' THEN 3 ELSE 4 END').all(p.id)}))}
 function putProduct(p){
  if(!p||!Number.isInteger(p.id)||p.id<1||!Number.isSafeInteger(p.price_minor)||p.price_minor<1||p.price_minor>100000000)throw new StoreError('Invalid product or price.');
  for(const key of ['name','category','color','description','image'])if(typeof p[key]!=='string'||!p[key].trim()||p[key].length>(key==='description'?3000:1000))throw new StoreError(`Invalid ${key}.`);
  if(!managedImagePath(p.image)){let image;try{image=new URL(p.image)}catch{throw new StoreError('Use an uploaded photo or a valid HTTPS URL.')}if(image.protocol!=='https:')throw new StoreError('Image must use HTTPS.');}
  if(!['Dresses','Tops','Bottoms','Layers'].includes(p.category))throw new StoreError('Unknown category.');
  if(!Array.isArray(p.variants)||p.variants.length!==5||new Set(p.variants.map(v=>v.size)).size!==5||p.variants.some(v=>!['XS','S','M','L','XL'].includes(v.size)||!Number.isInteger(v.stock)||v.stock<0||v.stock>100000))throw new StoreError('Provide stock for XS, S, M, L and XL.');
  if(typeof p.active!=='boolean')throw new StoreError('Active must be true or false.');
  transaction(()=>{db.prepare(`INSERT INTO products(id,name,category,color,description,image,price_minor,active) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,category=excluded.category,color=excluded.color,description=excluded.description,image=excluded.image,price_minor=excluded.price_minor,active=excluded.active`).run(p.id,p.name,p.category,p.color,p.description,p.image,p.price_minor,Number(p.active));for(const v of p.variants)db.prepare('INSERT INTO variants(product_id,size,stock) VALUES(?,?,?) ON CONFLICT(product_id,size) DO UPDATE SET stock=excluded.stock').run(p.id,v.size,v.stock);db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('product.updated',String(p.id))});
 }
 function quote(items,zone,zones){
  if(!Array.isArray(items)||items.length<1||items.length>30)throw new StoreError('Your bag must contain 1–30 different sizes.');
  const shipping=zones.find(z=>z.id===zone);if(!shipping||!Number.isSafeInteger(shipping.fee_minor)||shipping.fee_minor<0)throw new StoreError('Choose a supported delivery zone.');
  const seen=new Set();const lines=items.map(x=>{if(!x||!Number.isInteger(x.id)||!Number.isInteger(x.qty)||x.qty<1||x.qty>20||!['XS','S','M','L','XL'].includes(x.size))throw new StoreError('Invalid bag item.');const key=`${x.id}/${x.size}`;if(seen.has(key))throw new StoreError('Duplicate bag item.');seen.add(key);const p=db.prepare('SELECT p.*,v.stock FROM products p JOIN variants v ON v.product_id=p.id WHERE p.id=? AND v.size=? AND p.active=1').get(x.id,x.size);if(!p)throw new StoreError('A piece in your bag is no longer available.',409);if(x.qty>p.stock)throw new StoreError(`Not enough stock for ${p.name} in ${x.size}.`,409);return {id:p.id,name:p.name,size:x.size,qty:x.qty,unit_minor:p.price_minor,line_minor:p.price_minor*x.qty}});
  const subtotal_minor=lines.reduce((s,x)=>s+x.line_minor,0);return {items:lines,subtotal_minor,shipping_minor:shipping.fee_minor,total_minor:subtotal_minor+shipping.fee_minor,currency:'GHS',shipping_zone:zone};
 }
 function createOrder(input,zones,key){
  releaseExpired();
  if(typeof key!=='string'||! /^[a-zA-Z0-9_-]{32,100}$/.test(key))throw new StoreError('A valid idempotency key is required.');
  const c=input?.customer;if(!c||typeof c.name!=='string'||c.name.trim().length<2||c.name.length>100||typeof c.email!=='string'||c.email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)||typeof c.address!=='string'||c.address.trim().length<8||c.address.length>500||typeof c.phone!=='string'||! /^[+\d ()-]{7,25}$/.test(c.phone))throw new StoreError('Enter a valid name, email, phone and delivery address.');
  const customer={name:c.name.trim(),email:c.email.trim().toLowerCase(),phone:c.phone.trim(),address:c.address.trim()};const hash=digest(JSON.stringify({customer,items:input.items,zone:input.zone}));
  return transaction(()=>{
   const prior=db.prepare('SELECT id,request_hash FROM orders WHERE idempotency_key=?').get(key);if(prior){if(prior.request_hash!==hash)throw new StoreError('This checkout key was already used for a different order.',409);return {...db.prepare('SELECT id,status,payment_url,total_minor,currency FROM orders WHERE id=?').get(prior.id),token:digest('order-access:'+key),repeated:true}}
   const q=quote(input.items,input.zone,zones);const id='AF-'+randomBytes(10).toString('hex').toUpperCase();const token=digest('order-access:'+key);
   for(const x of q.items){const result=db.prepare('UPDATE variants SET stock=stock-? WHERE product_id=? AND size=? AND stock>=?').run(x.qty,x.id,x.size,x.qty);if(result.changes!==1)throw new StoreError('Stock changed. Please refresh your bag.',409)}
   db.prepare('INSERT INTO orders(id,token_hash,idempotency_key,request_hash,customer_json,items_json,subtotal_minor,shipping_minor,total_minor,status,shipping_zone) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(id,digest(token),key,hash,JSON.stringify(customer),JSON.stringify(q.items),q.subtotal_minor,q.shipping_minor,q.total_minor,'pending_payment',input.zone);
   db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('order.created',id);return {id,token,status:'pending_payment',...q};
  });
 }
 function order(id,token){const r=db.prepare('SELECT id,status,total_minor,currency,created_at FROM orders WHERE id=? AND token_hash=?').get(id,digest(token));if(!r)throw new StoreError('Order not found.',404);return r}
 function updateStatus(id,status){const allowed={paid:['processing'],processing:['shipped'],shipped:['completed']};return transaction(()=>{const r=db.prepare('SELECT * FROM orders WHERE id=?').get(id);if(!r)throw new StoreError('Order not found.',404);if(!allowed[r.status]?.includes(status))throw new StoreError('Invalid order transition. Payment status must be verified by the payment provider.',409);if(status==='cancelled')for(const x of JSON.parse(r.items_json))db.prepare('UPDATE variants SET stock=stock+? WHERE product_id=? AND size=?').run(x.qty,x.id,x.size);db.prepare('UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,id);db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run(`order.${status}`,id)})}
 function releaseExpired(now=Date.now()){
  return transaction(()=>{const cutoff=new Date(now-30*60*1000).toISOString().slice(0,19).replace('T',' ');const rows=db.prepare("SELECT id,items_json FROM orders WHERE status='pending_payment' AND created_at<?").all(cutoff);for(const r of rows){for(const x of JSON.parse(r.items_json))db.prepare('UPDATE variants SET stock=stock+? WHERE product_id=? AND size=?').run(x.qty,x.id,x.size);db.prepare("UPDATE orders SET status='expired',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id);db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('order.expired',r.id)}return rows.length})
 }
 function confirmPayment(payment){if(!payment||!['number','string'].includes(typeof payment.id)||!Number.isSafeInteger(payment.amount)||typeof payment.reference!=='string')throw new StoreError('Invalid payment data.');return transaction(()=>{
  const r=db.prepare('SELECT * FROM orders WHERE id=?').get(payment.reference);if(!r)throw new StoreError('Unknown payment reference.',404);
  if(payment.status!=='success'||payment.currency!==r.currency||payment.amount!==r.total_minor)throw new StoreError('Payment does not match this order.',409);
  if(['paid','processing','shipped','completed','payment_review','refunded'].includes(r.status))return {id:r.id,repeated:true};
  let status='paid';
  if(r.status==='expired'){
   const items=JSON.parse(r.items_json);const available=items.every(x=>{const v=db.prepare('SELECT stock FROM variants WHERE product_id=? AND size=?').get(x.id,x.size);return v&&v.stock>=x.qty});
   if(available){for(const x of items)db.prepare('UPDATE variants SET stock=stock-? WHERE product_id=? AND size=?').run(x.qty,x.id,x.size)}
   else status='payment_review';
  }else if(r.status!=='pending_payment')throw new StoreError('Payment requires manual reconciliation.',409);
  db.prepare('UPDATE orders SET status=?,payment_event_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,String(payment.id),r.id);
  db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run(status==='paid'?'payment.verified':'payment.stock_review',r.id);return {id:r.id,status};
 })}

 function confirmRefund(refund){return transaction(()=>{const reference=refund?.transaction?.reference;const r=db.prepare('SELECT * FROM orders WHERE id=?').get(reference||'');if(!r)throw new StoreError('Refund order was not found.',404);if(refund.status!=='processed'||refund.currency!==r.currency||refund.amount!==r.total_minor)throw new StoreError('Only a processed full refund in the order currency can be reconciled.',409);if(r.status==='refunded')return {repeated:true};if(!['paid','processing','shipped','completed','payment_review'].includes(r.status))throw new StoreError('This order has no verified payment to refund.',409);db.prepare("UPDATE orders SET status='refunded',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id);db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('refund.verified',r.id);return {id:r.id,status:'refunded'}})}

 return {db,catalogue,putProduct,quote,createOrder,order,updateStatus,confirmPayment,confirmRefund,releaseExpired,close:()=>db.close()};
}
