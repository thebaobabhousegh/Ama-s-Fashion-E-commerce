import { readFile } from 'node:fs/promises';
export async function requireLinkedCloud(){
 try{const project=JSON.parse(await readFile(new URL('../.vercel/project.json',import.meta.url),'utf8'));if(!project.projectId||!project.orgId)throw new Error()}catch{throw new Error('Link the intended Vercel project with vercel link before running cloud database commands.');}
 if(!/^(libsql|https):\/\//.test(process.env.TURSO_DATABASE_URL||'')||!process.env.TURSO_AUTH_TOKEN)throw new Error('Pull the linked project’s Turso/libSQL credentials into .env.vercel first.');
}
