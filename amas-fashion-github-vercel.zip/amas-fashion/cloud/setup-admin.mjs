import { createInterface, emitKeypressEvents } from 'node:readline';
import { mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openStore } from './commerce.mjs';
import { requireLinkedCloud } from './cli-preflight.mjs';
import { management } from './management.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
function ask(prompt){const rl=createInterface({input:process.stdin,output:process.stdout});return new Promise(r=>rl.question(prompt,v=>{rl.close();r(v)}))}
function secret(prompt){process.stdout.write(prompt);emitKeypressEvents(process.stdin);const prior=process.stdin.isRaw;process.stdin.setRawMode(true);process.stdin.resume();return new Promise((resolve,reject)=>{let value='';const finish=(error)=>{process.stdin.removeListener('keypress',read);process.stdin.setRawMode(prior||false);process.stdin.pause();process.stdout.write('\n');error?reject(error):resolve(value)};const read=(str,key={})=>{if(key.ctrl&&key.name==='c')return finish(new Error('Cancelled.'));if(key.name==='return')return finish();if(key.name==='backspace')value=Array.from(value).slice(0,-1).join('');else if(!key.ctrl&&!key.meta&&str&&!/[\x00-\x1f\x7f]/.test(str))value+=str;};process.stdin.on('keypress',read)})}
async function main(){if(!process.stdin.isTTY)throw new Error('Run this command in your own interactive Terminal.');await requireLinkedCloud();const store=await openStore();try{const m=(await management(store));const reset=process.argv.includes('--reset');if((await m.hasOwner())&&!reset)throw new Error('An owner already exists. Sign in, or run npm run reset:admin to reset credentials locally.');if((await m.hasOwner())&&reset){const answer=await ask('This signs out existing admin sessions. Type RESET to continue: ');if(answer!=='RESET')throw new Error('Cancelled.')}const email=(await ask('Owner email: ')).trim();const password=await secret('Choose a password (12–128 characters; hidden): ');const confirmation=await secret('Confirm password (hidden): ');if(password!==confirmation)throw new Error('Passwords do not match.');(await m.setOwner(email,password,{reset}));console.log('Owner account saved. Start the server and sign in at /admin. No password is printed or stored in plain text.')}finally{store.close()}}
main().catch(e=>{console.error(e.message);process.exitCode=1});
