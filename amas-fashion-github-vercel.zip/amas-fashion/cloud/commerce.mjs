import { connectDatabase } from './database.mjs';
import { randomBytes, createHash } from 'node:crypto';
import { managedImagePath } from '../server/images.mjs';
import { StoreError } from '../server/errors.mjs';
export { StoreError } from '../server/errors.mjs';
export const digest=v=>createHash('sha256').update(v).digest('hex');
export async function openStore(path,options={}){
 const db=await connectDatabase(path,options);
 if(options.initialize)await db.initialize();
 const transaction=async fn=>{(await db.exec('BEGIN IMMEDIATE'));try{const r=(await fn());(await db.exec('COMMIT'));return r}catch(e){(await db.exec('ROLLBACK'));throw e}};
 async function catalogue(includeInactive=false){return (await Promise.all((await db.prepare(`SELECT * FROM products ${includeInactive?'':'WHERE active=1'} ORDER BY id`).all()).map(async p=>({...p,active:!!p.active,price:p.price_minor/100,variants:(await db.prepare('SELECT size,stock FROM variants WHERE product_id=? ORDER BY CASE size WHEN \'XS\' THEN 0 WHEN \'S\' THEN 1 WHEN \'M\' THEN 2 WHEN \'L\' THEN 3 ELSE 4 END').all(p.id))}))))}
 async function putProduct(p){
  if(!p||!Number.isInteger(p.id)||p.id<1||!Number.isSafeInteger(p.price_minor)||p.price_minor<1||p.price_minor>100000000)throw new StoreError('Invalid product or price.');
  for(const key of ['name','category','color','description','image'])if(typeof p[key]!=='string'||!p[key].trim()||p[key].length>(key==='description'?3000:1000))throw new StoreError(`Invalid ${key}.`);
  if(!managedImagePath(p.image)){let image;try{image=new URL(p.image)}catch{throw new StoreError('Use an uploaded photo or a valid HTTPS URL.')}if(image.protocol!=='https:')throw new StoreError('Image must use HTTPS.');}
  if(!['Dresses','Tops','Bottoms','Layers'].includes(p.category))throw new StoreError('Unknown category.');
  if(!Array.isArray(p.variants)||p.variants.length!==5||new Set(p.variants.map(v=>v.size)).size!==5||p.variants.some(v=>!['XS','S','M','L','XL'].includes(v.size)||!Number.isInteger(v.stock)||v.stock<0||v.stock>100000))throw new StoreError('Provide stock for XS, S, M, L and XL.');
  if(typeof p.active!=='boolean')throw new StoreError('Active must be true or false.');
  (await transaction(async ()=>{(await db.prepare(`INSERT INTO products(id,name,category,color,description,image,price_minor,active) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,category=excluded.category,color=excluded.color,description=excluded.description,image=excluded.image,price_minor=excluded.price_minor,active=excluded.active`).run(p.id,p.name,p.category,p.color,p.description,p.image,p.price_minor,Number(p.active)));for(const v of p.variants)(await db.prepare('INSERT INTO variants(product_id,size,stock) VALUES(?,?,?) ON CONFLICT(product_id,size) DO UPDATE SET stock=excluded.stock').run(p.id,v.size,v.stock));(await db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('product.updated',String(p.id)))}));
 }
 async function quote(items,zone,zones){
  if(!Array.isArray(items)||items.length<1||items.length>30)throw new StoreError('Your bag must contain 1–30 different sizes.');
  const shipping=zones.find(z=>z.id===zone);if(!shipping||!Number.isSafeInteger(shipping.fee_minor)||shipping.fee_minor<0)throw new StoreError('Choose a supported delivery zone.');
  const seen=new Set();const lines=(await Promise.all(items.map(async x=>{if(!x||!Number.isInteger(x.id)||!Number.isInteger(x.qty)||x.qty<1||x.qty>20||!['XS','S','M','L','XL'].includes(x.size))throw new StoreError('Invalid bag item.');const key=`${x.id}/${x.size}`;if(seen.has(key))throw new StoreError('Duplicate bag item.');seen.add(key);const p=(await db.prepare('SELECT p.*,v.stock FROM products p JOIN variants v ON v.product_id=p.id WHERE p.id=? AND v.size=? AND p.active=1').get(x.id,x.size));if(!p)throw new StoreError('A piece in your bag is no longer available.',409);if(x.qty>p.stock)throw new StoreError(`Not enough stock for ${p.name} in ${x.size}.`,409);return {id:p.id,name:p.name,size:x.size,qty:x.qty,unit_minor:p.price_minor,line_minor:p.price_minor*x.qty}})));
  const subtotal_minor=lines.reduce((s,x)=>s+x.line_minor,0);return {items:lines,subtotal_minor,shipping_minor:shipping.fee_minor,total_minor:subtotal_minor+shipping.fee_minor,currency:'GHS',shipping_zone:zone};
 }
 async function createOrder(input,zones,key){
  (await releaseExpired());
  if(typeof key!=='string'||! /^[a-zA-Z0-9_-]{32,100}$/.test(key))throw new StoreError('A valid idempotency key is required.');
  const c=input?.customer;if(!c||typeof c.name!=='string'||c.name.trim().length<2||c.name.length>100||typeof c.email!=='string'||c.email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)||typeof c.address!=='string'||c.address.trim().length<8||c.address.length>500||typeof c.phone!=='string'||! /^[+\d ()-]{7,25}$/.test(c.phone))throw new StoreError('Enter a valid name, email, phone and delivery address.');
  const customer={name:c.name.trim(),email:c.email.trim().toLowerCase(),phone:c.phone.trim(),address:c.address.trim()};const hash=digest(JSON.stringify({customer,items:input.items,zone:input.zone}));
  return (await transaction(async ()=>{
   const prior=(await db.prepare('SELECT id,request_hash FROM orders WHERE idempotency_key=?').get(key));if(prior){if(prior.request_hash!==hash)throw new StoreError('This checkout key was already used for a different order.',409);return {...(await db.prepare('SELECT id,status,payment_url,total_minor,currency FROM orders WHERE id=?').get(prior.id)),token:digest('order-access:'+key),repeated:true}}
   const q=(await quote(input.items,input.zone,zones));const id='AF-'+randomBytes(10).toString('hex').toUpperCase();const token=digest('order-access:'+key);
   for(const x of q.items){const result=(await db.prepare('UPDATE variants SET stock=stock-? WHERE product_id=? AND size=? AND stock>=?').run(x.qty,x.id,x.size,x.qty));if(result.changes!==1)throw new StoreError('Stock changed. Please refresh your bag.',409)}
   (await db.prepare('INSERT INTO orders(id,token_hash,idempotency_key,request_hash,customer_json,items_json,subtotal_minor,shipping_minor,total_minor,status,shipping_zone) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(id,digest(token),key,hash,JSON.stringify(customer),JSON.stringify(q.items),q.subtotal_minor,q.shipping_minor,q.total_minor,'pending_payment',input.zone));
   (await db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('order.created',id));return {id,token,status:'pending_payment',...q};
  }));
 }
 async function order(id,token){const r=(await db.prepare('SELECT id,status,total_minor,currency,created_at FROM orders WHERE id=? AND token_hash=?').get(id,digest(token)));if(!r)throw new StoreError('Order not found.',404);return r}
 async function updateStatus(id,status){const allowed={paid:['processing'],processing:['shipped'],shipped:['completed']};return (await transaction(async ()=>{const r=(await db.prepare('SELECT * FROM orders WHERE id=?').get(id));if(!r)throw new StoreError('Order not found.',404);if(!allowed[r.status]?.includes(status))throw new StoreError('Invalid order transition. Payment status must be verified by the payment provider.',409);if(status==='cancelled')for(const x of JSON.parse(r.items_json))(await db.prepare('UPDATE variants SET stock=stock+? WHERE product_id=? AND size=?').run(x.qty,x.id,x.size));(await db.prepare('UPDATE orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,id));(await db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run(`order.${status}`,id))}))}
 async function releaseExpired(now=Date.now()){
  return (await transaction(async ()=>{const cutoff=new Date(now-30*60*1000).toISOString().slice(0,19).replace('T',' ');const rows=(await db.prepare("SELECT id,items_json FROM orders WHERE status='pending_payment' AND created_at<?").all(cutoff));for(const r of rows){for(const x of JSON.parse(r.items_json))(await db.prepare('UPDATE variants SET stock=stock+? WHERE product_id=? AND size=?').run(x.qty,x.id,x.size));(await db.prepare("UPDATE orders SET status='expired',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id));(await db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('order.expired',r.id))}return rows.length}))
 }
 async function confirmPayment(payment){if(!payment||!['number','string'].includes(typeof payment.id)||!Number.isSafeInteger(payment.amount)||typeof payment.reference!=='string')throw new StoreError('Invalid payment data.');return (await transaction(async ()=>{
  const r=(await db.prepare('SELECT * FROM orders WHERE id=?').get(payment.reference));if(!r)throw new StoreError('Unknown payment reference.',404);
  if(payment.status!=='success'||payment.currency!==r.currency||payment.amount!==r.total_minor)throw new StoreError('Payment does not match this order.',409);
  if(['paid','processing','shipped','completed','payment_review','refunded'].includes(r.status))return {id:r.id,repeated:true};
  let status='paid';
  if(r.status==='expired'){
   const items=JSON.parse(r.items_json);const checks=(await Promise.all(items.map(async x=>{const v=(await db.prepare('SELECT stock FROM variants WHERE product_id=? AND size=?').get(x.id,x.size));return v&&v.stock>=x.qty})));
   if(checks.every(Boolean)){for(const x of items)(await db.prepare('UPDATE variants SET stock=stock-? WHERE product_id=? AND size=?').run(x.qty,x.id,x.size))}
   else status='payment_review';
  }else if(r.status!=='pending_payment')throw new StoreError('Payment requires manual reconciliation.',409);
  (await db.prepare('UPDATE orders SET status=?,payment_event_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,String(payment.id),r.id));
  (await db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run(status==='paid'?'payment.verified':'payment.stock_review',r.id));return {id:r.id,status};
 }))}

 async function confirmRefund(refund){return (await transaction(async ()=>{const reference=refund?.transaction?.reference;const r=(await db.prepare('SELECT * FROM orders WHERE id=?').get(reference||''));if(!r)throw new StoreError('Refund order was not found.',404);if(refund.status!=='processed'||refund.currency!==r.currency||refund.amount!==r.total_minor)throw new StoreError('Only a processed full refund in the order currency can be reconciled.',409);if(r.status==='refunded')return {repeated:true};if(!['paid','processing','shipped','completed','payment_review'].includes(r.status))throw new StoreError('This order has no verified payment to refund.',409);(await db.prepare("UPDATE orders SET status='refunded',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id));(await db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('refund.verified',r.id));return {id:r.id,status:'refunded'}}))}

 return {db,catalogue,putProduct,quote,createOrder,order,updateStatus,confirmPayment,confirmRefund,releaseExpired,close:()=>db.close()};
}
