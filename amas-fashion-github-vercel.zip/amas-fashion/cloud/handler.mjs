
import { readFile, mkdir } from 'node:fs/promises';
import { dirname, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, timingSafeEqual, createHmac } from 'node:crypto';
import { StoreError,digest } from './commerce.mjs';
import { management } from './management.mjs';
import { saveImage } from './images.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
export function configuration(env=process.env){
 const origin=new URL(env.PUBLIC_ORIGIN||'http://127.0.0.1:8000');const production=env.NODE_ENV==='production';
 if(production&&origin.protocol!=='https:')throw new Error('Production PUBLIC_ORIGIN must use HTTPS.');
 if(origin.pathname!=='/'||origin.username||origin.password||origin.search||origin.hash)throw new Error('PUBLIC_ORIGIN must contain an origin only.');
 let zones;try{zones=JSON.parse(env.SHIPPING_ZONES||'[]')}catch{throw new Error('SHIPPING_ZONES must be JSON.')}
 if(!Array.isArray(zones)||zones.some(z=>!z||typeof z.id!=='string'||! /^[a-z0-9-]{1,40}$/.test(z.id)||typeof z.name!=='string'||z.name.length>100||!Number.isSafeInteger(z.fee_minor)||z.fee_minor<0||z.fee_minor>10000000)||new Set(zones.map(z=>z.id)).size!==zones.length)throw new Error('Invalid delivery-zone configuration.');
 const key=env.PAYSTACK_SECRET_KEY||'';const approved=env.CATALOGUE_APPROVED==='true';const requested=env.CHECKOUT_ENABLED==='true';
 if(requested&&(!key||!approved))throw new Error('Checkout requires a payment key, approved catalogue and shipping zones.');
 if(key&&! /^sk_(test|live)_[a-zA-Z0-9]+$/.test(key))throw new Error('Invalid Paystack secret-key format.');
 if(key.startsWith('sk_live_')&&env.LIVE_SALES_APPROVED!=='true')throw new Error('Explicit LIVE_SALES_APPROVED=true is required for a live payment key.');
 if(env.ADMIN_TOKEN&&env.ADMIN_TOKEN.length<32)throw new Error('ADMIN_TOKEN must have at least 32 characters.');
 return {origin:origin.origin,production,zones,key,approved,checkout:requested,adminToken:env.ADMIN_TOKEN||''};
}
const equal=(a,b)=>timingSafeEqual(Buffer.from(digest(a)),Buffer.from(digest(b)));
export async function createHandler(store,config,{gateway=fetch,clock=Date.now,uploadsDirectory=resolve(dirname(resolve(process.env.DATABASE_PATH||resolve(root,'data/store.sqlite'))),'uploads')}={}){
 const manage=(await management(store,{zones:config.zones}));
 async function limit(key,max){const window=Math.floor(clock()/60000);const result=await store.db.prepare('INSERT INTO request_limits(key,window,count) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET window=excluded.window,count=CASE WHEN request_limits.window=excluded.window THEN request_limits.count+1 ELSE 1 END RETURNING count').get(digest(key),window);if(result.count>max)throw new StoreError('Too many requests. Please try again in a minute.',429);}
 async function paystack(path,method='GET',data){if(!config.key)throw new StoreError('Payment service is not connected.',503);let r;try{r=await gateway('https://api.paystack.co'+path,{method,headers:{Authorization:`Bearer ${config.key}`,'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined,signal:AbortSignal.timeout(15000)})}catch{throw new StoreError('Payment provider could not be reached. Retry with the same checkout.',502)}let result;try{result=await r.json()}catch{throw new StoreError('Payment provider returned an invalid response.',502)}if(!r.ok||!result.status)throw new StoreError('Payment provider could not complete the request. Please retry.',502);return result.data}
 return async(req,res)=>{
  const requestId=randomBytes(8).toString('hex');
  const headers={'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','X-Frame-Options':'DENY','Permissions-Policy':'camera=(), microphone=(), geolocation=()','Cache-Control':'no-store','X-Request-Id':requestId,'Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; connect-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'"};if(config.production)headers['Strict-Transport-Security']='max-age=31536000';
  function json(status,value,extra={}){res.writeHead(status,{...headers,'Content-Type':'application/json; charset=utf-8',...extra});res.end(JSON.stringify(value))}
  try{
   const url=new URL(req.url,config.origin);const path=url.pathname;const method=req.method;const settings=(await manage.getSettings());const zones=settings.shipping_zones;const checkoutOpen=config.checkout&&zones.length>0;
   if(req.headers.host!==new URL(config.origin).host)throw new StoreError('Invalid host.',400);
   const webhook=path==='/api/payments/paystack/webhook';
   if(!['GET','HEAD'].includes(method)&&!webhook&&req.headers.origin!==config.origin)throw new StoreError('Cross-origin request rejected.',403);
   let raw=Buffer.alloc(0),data;
   if(!['GET','HEAD'].includes(method)){for await(const chunk of req){raw=Buffer.concat([raw,chunk]);if(raw.length>(path==='/api/admin/images'?2900000:path==='/api/admin/settings'?131072:32768))throw new StoreError('Request is too large.',413)}if(!req.headers['content-type']?.startsWith('application/json'))throw new StoreError('JSON content type required.',415);try{data=JSON.parse(raw.toString())}catch{throw new StoreError('Invalid JSON.')}if(!data||typeof data!=='object'||Array.isArray(data))throw new StoreError('A JSON object is required.');}
   const ip=req.cloudClientIp||'unknown';
   if(path.startsWith('/api/'))(await limit(ip,180));
   if(path==='/api/admin/auth-mode'&&method==='GET')return json(200,{password_login:(await manage.hasOwner()),legacy_token_login:!(await manage.hasOwner())&&!!config.adminToken});
   if(path==='/api/health'&&method==='GET'){(await store.db.prepare('SELECT 1').get());return json(200,{status:'ok'})}
   if(path==='/api/config'&&method==='GET')return json(200,{currency:'GHS',checkout_enabled:checkoutOpen,catalogue_approved:config.approved,payment_mode:config.key.startsWith('sk_live_')?'live':'test',shipping_zones:zones,storefront:settings.content});
   if(path==='/api/products'&&method==='GET'){(await store.releaseExpired());return json(200,{products:(await store.catalogue())});}
   if(path==='/api/cart/quote'&&method==='POST'){(await store.releaseExpired());const prior=typeof req.headers['idempotency-key']==='string'?(await store.db.prepare("SELECT * FROM orders WHERE idempotency_key=? AND status='pending_payment'").get(req.headers['idempotency-key'])):null;if(prior){const original=JSON.parse(prior.items_json);const normalized=items=>Array.isArray(items)?JSON.stringify(items.map(x=>({id:x?.id,size:x?.size,qty:x?.qty})).sort((a,b)=>a.id-b.id||String(a.size).localeCompare(String(b.size)))):'';if(data.zone===prior.shipping_zone&&normalized(original)===normalized(data.items))return json(200,{items:original,subtotal_minor:prior.subtotal_minor,shipping_minor:prior.shipping_minor,total_minor:prior.total_minor,currency:prior.currency,shipping_zone:prior.shipping_zone});}return json(200,(await store.quote(data.items,data.zone,zones)));}
   if(path==='/api/checkout'&&method==='POST'){
    (await limit('checkout:'+ip,10));if(!checkoutOpen)throw new StoreError('Checkout is not open yet. Please check back soon.',503);
    const order=(await store.createOrder(data,zones,req.headers['idempotency-key']));
    if(order.repeated&&order.status!=='pending_payment')return json(409,{error:order.status==='expired'?'Your stock reservation expired. Please start a fresh checkout.':'This order has already been submitted.',code:order.status==='expired'?'RESERVATION_EXPIRED':'ORDER_ALREADY_SUBMITTED'});
    let paymentUrl=order.payment_url;
    if(!paymentUrl){
     // Verify the reference before retrying initialization after an uncertain network result.
     if(order.repeated){try{const previous=await paystack('/transaction/verify/'+encodeURIComponent(order.id));if(previous.status==='success'){(await store.confirmPayment(previous));return json(409,{error:'Payment already received. Contact the store with your reference.'})}}catch(e){if(e.status===409)throw e; /* Initialization below keeps the same provider reference. */}}
     const result=await paystack('/transaction/initialize','POST',{reference:order.id,email:data.customer.email,amount:order.total_minor,currency:'GHS',channels:['card','mobile_money'],callback_url:config.origin+'/?payment_reference='+encodeURIComponent(order.id),metadata:{order_id:order.id}});
     const checkout=new URL(result.authorization_url);if(checkout.protocol!=='https:'||checkout.hostname!=='checkout.paystack.com')throw new StoreError('Invalid payment destination.',502);paymentUrl=checkout.href;(await store.db.prepare('UPDATE orders SET payment_url=? WHERE id=?').run(paymentUrl,order.id));
    }
    return json(order.repeated?200:201,{id:order.id,token:order.token,payment_url:paymentUrl,total_minor:order.total_minor,currency:'GHS'});
   }
   if(webhook&&method==='POST'){
    if(!config.key)throw new StoreError('Payments are not configured.',503);
    const signature=req.headers['x-paystack-signature'];const expected=createHmac('sha512',config.key).update(raw).digest('hex');if(typeof signature!=='string'||!equal(signature,expected))throw new StoreError('Invalid webhook signature.',401);
    if(data.event==='charge.success'){const verified=await paystack('/transaction/verify/'+encodeURIComponent(data.data?.reference||''));(await store.confirmPayment(verified))}
    return json(200,{received:true});
   }
   if(path==='/api/orders/verify'&&method==='POST'){
    (await limit('verify:'+ip,15));if(typeof data.id!=='string'||typeof data.token!=='string')throw new StoreError('Order credentials required.',401);const existing=(await store.order(data.id,data.token));if(['pending_payment','expired'].includes(existing.status)){const result=await paystack('/transaction/verify/'+encodeURIComponent(data.id));if(result.status==='success')(await store.confirmPayment(result))}return json(200,(await store.order(data.id,data.token)));
   }
   if(path==='/api/admin/login'&&method==='POST'){
    (await limit('login:'+ip,5));if((await manage.hasOwner())?!(await manage.authenticate(data.email,data.password)):(!config.adminToken||typeof data.token!=='string'||!equal(config.adminToken,data.token)))throw new StoreError('Invalid administrator credentials.',401);
    const token=randomBytes(32).toString('hex');(await store.db.prepare('DELETE FROM admin_sessions WHERE expires_at<?').run(clock()));(await store.db.prepare('INSERT INTO admin_sessions VALUES(?,?)').run(digest(token),clock()+3600000));return json(200,{signed_in:true},{'Set-Cookie':`ama_admin=${token}; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=3600${config.production?'; Secure':''}`});
   }
   if(path.startsWith('/api/admin/')){
    const token=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('ama_admin='))?.slice(10)||'';const session=(await store.db.prepare('SELECT expires_at FROM admin_sessions WHERE token_hash=?').get(digest(token)));if(!session||session.expires_at<clock())throw new StoreError('Administrator sign-in required.',401);
    if(path==='/api/admin/logout'&&method==='POST'){(await store.db.prepare('DELETE FROM admin_sessions WHERE token_hash=?').run(digest(token)));return json(200,{signed_in:false},{'Set-Cookie':'ama_admin=; HttpOnly; SameSite=Strict; Path=/api/admin; Max-Age=0'})}
    if(path==='/api/admin/images'&&method==='POST')return json(201,await saveImage(uploadsDirectory,data));
    if(path==='/api/admin/overview'&&method==='GET')return json(200,(await manage.overview()));
    if(path==='/api/admin/settings'&&method==='GET')return json(200,(await manage.getSettings()));
    if(path==='/api/admin/settings'&&method==='PUT'){if(config.checkout&&(!Array.isArray(data.shipping_zones)||!data.shipping_zones.length))throw new StoreError('Keep at least one delivery area while checkout is enabled.');return json(200,(await manage.saveSettings(data)));}
    if(path==='/api/admin/activity'&&method==='GET')return json(200,{events:(await store.db.prepare('SELECT action,resource_id,created_at FROM audit ORDER BY id DESC LIMIT 50').all())});
    if(path==='/api/admin/products'&&method==='GET')return json(200,{products:(await store.catalogue(true))});
    if(path==='/api/admin/products'&&method==='PUT'){(await store.putProduct(data));return json(200,{saved:true})}
    if(path==='/api/admin/orders'&&method==='GET')return json(200,(await manage.orders({page:Number(url.searchParams.get('page')||1),status:url.searchParams.get('status')||'',q:url.searchParams.get('q')||''})));
    if(path==='/api/admin/orders/status'&&method==='POST'){(await store.updateStatus(data.id,data.status));return json(200,{updated:true})}
    if(path==='/api/admin/orders/refund/verify'&&method==='POST'){if(!/^[0-9]{1,20}$/.test(String(data.refund_id)))throw new StoreError('Valid Paystack refund ID required.');const refund=await paystack('/refund/'+encodeURIComponent(data.refund_id));if(refund.transaction?.reference!==data.id)throw new StoreError('Refund does not belong to this order.',409);return json(200,(await store.confirmRefund(refund)));}
    if(path==='/api/admin/orders/reconcile'&&method==='POST'){if(typeof data.id!=='string')throw new StoreError('Order reference required.');const p=await paystack('/transaction/verify/'+encodeURIComponent(data.id));if(p.status==='success')(await store.confirmPayment(p));return json(200,{payment_status:p.status})}
   }
   if(path.startsWith('/api/'))throw new StoreError('Endpoint not found.',404);
   if(!['GET','HEAD'].includes(method))throw new StoreError('Method not allowed.',405);
   if(path.startsWith('/uploads/'))throw new StoreError('Photo must be migrated to cloud storage.',404);
   const files={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/production.js':'production.js','/styles.css':'styles.css','/admin':'admin.html','/admin/':'admin.html','/admin.js':'admin.js','/admin.css':'admin.css','/robots.txt':'robots.txt'};const file=files[path];if(!file)throw new StoreError('Page not found.',404);
   const content=await readFile(resolve(root,'dist',file));const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.txt':'text/plain; charset=utf-8'};
   res.writeHead(200,{...headers,'Content-Type':types[extname(file)]||'application/octet-stream','Content-Length':content.length});res.end(method==='HEAD'?undefined:content);
  }catch(e){if(!res.headersSent)json(e instanceof StoreError?e.status:500,{error:e instanceof StoreError?e.message:'Something went wrong. Please try again.',request_id:requestId});else res.end();if(!(e instanceof StoreError))console.error(JSON.stringify({request_id:requestId,error:'internal_error'}))}
 };
}