// Derive asynchronous cloud modules from the tested local implementation.
// This keeps the business rules shared while the database drivers differ.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parse } from 'acorn';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
function walk(node,callback,parent=null){if(!node||typeof node!=='object')return;callback(node,parent);for(const [key,value]of Object.entries(node)){if(['start','end','loc'].includes(key))continue;if(Array.isArray(value))for(const item of value)if(item?.type)walk(item,callback,node);else{}else if(value?.type)walk(value,callback,node)}}
function isFunction(n){return ['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(n?.type)}
function nameOf(n){return n?.type==='Identifier'?n.name:n?.type==='MemberExpression'?n.property.name:null}
const serviceMethods=new Set(['catalogue','putProduct','quote','createOrder','order','updateStatus','confirmPayment','confirmRefund','releaseExpired','getSettings','saveSettings','hasOwner','setOwner','authenticate','overview','orders']);
function asyncify(source){
 for(let pass=0;pass<20;pass++){
  const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),parents=new Map(),functions=[];
  walk(ast,(n,p)=>{parents.set(n,p);if(isFunction(n))functions.push(n)});
  const fnNames=new Map();for(const f of functions){const p=parents.get(f);if(f.id)fnNames.set(f.id.name,f);if(p?.type==='VariableDeclarator'&&p.id.type==='Identifier')fnNames.set(p.id.name,f)}
  const changes=[];const add=(at,text)=>changes.push({at,text});
  const mark=fn=>{if(fn&&!fn.async){fn.async=true;add(fn.start,'async ')}};
  const enclosing=n=>{let p=parents.get(n);while(p&&!isFunction(p))p=parents.get(p);return p};
  const wrap=(n,prefix='(await ',suffix=')')=>{if(parents.get(n)?.type==='AwaitExpression')return;add(n.start,prefix);add(n.end,suffix);mark(enclosing(n))};
  // First propagate async through SQL and service calls, then named local calls.
  walk(ast,n=>{if(n.type!=='CallExpression')return;const method=nameOf(n.callee);const object=n.callee.type==='MemberExpression'?n.callee.object:null;
   const sql=['get','all','run'].includes(method)&&object?.type==='CallExpression'&&nameOf(object.callee)==='prepare';
   const sqlExec=method==='exec'&&nameOf(object)==='db';
   const external=!!object&&serviceMethods.has(method);
   const named=n.callee.type==='Identifier'&&(fnNames.get(method)?.async||['openStore','management','createHandler','fixture'].includes(method));
   if(sql||sqlExec||external||named)wrap(n);
   if(method==='fn'&&n.callee.type==='Identifier')wrap(n);
  });
  // map(async ...) must be collected, not returned as promises in response objects.
  walk(ast,n=>{if(n.type!=='CallExpression'||nameOf(n.callee)!=='map'||!n.arguments[0]?.async)return;let p=parents.get(n);if(p?.type==='CallExpression'&&p.callee?.type==='MemberExpression'&&nameOf(p.callee)==='all')return;wrap(n,'(await Promise.all(', '))')});
  // Assertions on async operations use rejects; async tests retain their assertions.
  walk(ast,n=>{if(n.type==='CallExpression'&&n.callee.type==='MemberExpression'&&n.callee.object.name==='assert'&&n.callee.property.name==='throws'&&n.arguments[0]?.async){changes.push({at:n.callee.property.start,text:'rejects',remove:n.callee.property.end-n.callee.property.start});wrap(n)}});
  if(!changes.length)return source;
  // Inserts sharing a location are applied in reverse encounter order.
  changes.sort((a,b)=>b.at-a.at);for(const c of changes)source=source.slice(0,c.at)+c.text+source.slice(c.at+(c.remove||0));
 }
 throw new Error('Cloud async conversion did not converge.');
}
await mkdir(resolve(root,'cloud'),{recursive:true});
let commerce=await readFile(resolve(root,'server/commerce.mjs'),'utf8');
const schemaMatch=commerce.match(/ db\.exec\(`([\s\S]*?)`\);/);if(!schemaMatch)throw new Error('Schema source not found.');
const managementSource=await readFile(resolve(root,'server/management.mjs'),'utf8');const managementSchema=managementSource.match(/ db\.exec\(`([\s\S]*?)`\);/);if(!managementSchema)throw new Error('Management schema not found.');
await writeFile(resolve(root,'cloud/schema.sql'),schemaMatch[1]+'\n'+managementSchema[1]+'\nCREATE TABLE IF NOT EXISTS request_limits(key TEXT PRIMARY KEY, window INTEGER NOT NULL, count INTEGER NOT NULL);\n');
commerce=commerce.replace("import { DatabaseSync } from 'node:sqlite';","import { connectDatabase } from './database.mjs';").replaceAll("from './errors.mjs'","from '../server/errors.mjs'").replace("from './images.mjs'","from '../server/images.mjs'");
commerce=commerce.replace("export function openStore(path=':memory:'){", "export async function openStore(path,options={}){");
commerce=commerce.replace(/ const db=new DatabaseSync\(path\);db\.exec\('[^']*'\);/," const db=await connectDatabase(path,options);");
commerce=commerce.replace(/ db\.exec\(`[\s\S]*?`\);/," if(options.initialize)await db.initialize();");
commerce=commerce.replace("const available=items.every(x=>{", "const checks=items.map(x=>{").replace("return v&&v.stock>=x.qty});\n   if(available)","return v&&v.stock>=x.qty});\n   if(checks.every(Boolean))");
// The mapping awaits each row before checking stock availability.
commerce=asyncify(commerce);await writeFile(resolve(root,'cloud/commerce.mjs'),commerce);
let manage=managementSource.replace("from './commerce.mjs'","from '../server/errors.mjs'").replace("from './images.mjs'","from '../server/images.mjs'").replace(/ db\.exec\(`[\s\S]*?`\);/, '');manage=asyncify(manage);await writeFile(resolve(root,'cloud/management.mjs'),manage);
let server=await readFile(resolve(root,'server/index.mjs'),'utf8');server=server.slice(0,server.indexOf('\nasync function main()'));
server=server.replace("import http from 'node:http';",'').replace("import { openStore, StoreError, digest } from './commerce.mjs';","import { StoreError,digest } from '../server/commerce.mjs';").replace("from './management.mjs'","from './management.mjs'").replace("import { saveImage, readImage } from './images.mjs';", "import { saveImage } from './images.mjs';");
server=server.replace(/if\(path\.startsWith\('\/uploads\/'\)\)\{[^\n]+\}/,"if(path.startsWith('/uploads/'))throw new StoreError('Photo must be migrated to cloud storage.',404);");
// SQLite host request metadata is intentionally not used as a rate-limit key in serverless.
server=server.replace(/ const attempts=new Map\(\);function limit\([\s\S]*?\n async function paystack/,` async function limit(key,max){const window=Math.floor(clock()/60000);const result=await store.db.prepare('INSERT INTO request_limits(key,window,count) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET window=excluded.window,count=CASE WHEN request_limits.window=excluded.window THEN request_limits.count+1 ELSE 1 END RETURNING count').get(digest(key),window);if(result.count>max)throw new StoreError('Too many requests. Please try again in a minute.',429);}\n async function paystack`);
server=server.replace("const ip=req.socket.remoteAddress||'unknown';", "const ip=req.cloudClientIp||'unknown';");
// Vercel's platform handles the public static assets; paths are retained for API parity tests.
server=server.replace("from '../server/commerce.mjs'","from './commerce.mjs'");
server=server.replace("if(path==='/api/products'&&method==='GET')return json(200,{products:store.catalogue()});","if(path==='/api/products'&&method==='GET'){store.releaseExpired();return json(200,{products:store.catalogue()});}");
server=asyncify(server);await writeFile(resolve(root,'cloud/handler.mjs'),server);
let tests=await readFile(resolve(root,'tests/commerce.test.mjs'),'utf8');
tests=tests.slice(0,tests.indexOf("test('photo uploads"));
tests=tests.replace("from '../server/commerce.mjs'","from '../cloud/commerce.mjs'").replace("from '../server/index.mjs'","from '../cloud/handler.mjs'").replace("from '../server/management.mjs'","from '../cloud/management.mjs'").replace('const s=openStore();',"const s=openStore(':memory:',{initialize:true});");
tests=asyncify(tests);await writeFile(resolve(root,'tests/cloud-parity.test.mjs'),tests);
console.log('Prepared cloud API, database schema and parity tests. No resources provisioned or data uploaded.');

let owner=await readFile(resolve(root,'server/setup-admin.mjs'),'utf8');
owner=owner.replace("import { openStore } from './commerce.mjs';", "import { openStore } from './commerce.mjs';\nimport { requireLinkedCloud } from './cli-preflight.mjs';");
owner=owner.replace(/const file=resolve\(process.env.DATABASE_PATH[\s\S]*?const store=openStore\(file\);/,"await requireLinkedCloud();const store=await openStore();");
owner=asyncify(owner).replace('(await main()).catch','main().catch');await writeFile(resolve(root,'cloud/setup-admin.mjs'),owner);
