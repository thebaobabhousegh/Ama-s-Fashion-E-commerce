import { DatabaseSync } from 'node:sqlite';
import { readFile } from 'node:fs/promises';
import { dirname,resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openStore } from './commerce.mjs';
import { saveImage } from './images.mjs';
import { managedImagePath } from '../server/images.mjs';
import { requireLinkedCloud } from './cli-preflight.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const tables=['products','variants','orders','store_settings','owner_account','audit'];
export async function importLocal({file,store,upload=saveImage}){
 const source=new DatabaseSync(file,{readOnly:true});const snapshot={};
 try{source.exec('BEGIN');for(const table of tables){const exists=source.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(table);snapshot[table]=exists?source.prepare('SELECT * FROM '+table).all():[]}source.exec('COMMIT')}finally{source.close()}
 for(const table of tables)if((await store.db.prepare('SELECT COUNT(*) AS n FROM '+table).get()).n)throw new Error('Cloud database already contains store data. Import refused to avoid overwriting it.');
 const converted=new Map();
 async function photo(url){if(!managedImagePath(url))return url;if(converted.has(url))return converted.get(url);const extension=url.split('.').pop();const types={jpg:'image/jpeg',png:'image/png',webp:'image/webp'};const buffer=await readFile(resolve(dirname(file),url.slice(1)));const result=await upload(null,{type:types[extension],data_base64:buffer.toString('base64')});converted.set(url,result.url);return result.url}
 for(const p of snapshot.products)p.image=await photo(p.image);
 for(const row of snapshot.store_settings){const content=JSON.parse(row.content_json);if(content.hero_image)content.hero_image=await photo(content.hero_image);row.content_json=JSON.stringify(content)}
 await store.db.exec('BEGIN IMMEDIATE');try{
  // Recheck emptiness while holding the write transaction, not only before uploads.
  for(const table of tables)if((await store.db.prepare('SELECT COUNT(*) AS n FROM '+table).get()).n)throw new Error('Cloud store changed during import. Import was cancelled.');
  for(const table of tables)for(const row of snapshot[table]){const columns=Object.keys(row);if(columns.some(c=>! /^[a-z_]+$/.test(c)))throw new Error('Unexpected local schema.');await store.db.prepare(`INSERT INTO ${table} (${columns.join(',')}) VALUES (${columns.map(()=>'?').join(',')})`).run(...columns.map(c=>row[c]));}
  await store.db.prepare('INSERT INTO audit(action,resource_id) VALUES(?,?)').run('store.imported','local');await store.db.exec('COMMIT');return {products:snapshot.products.length,orders:snapshot.orders.length,owner_imported:snapshot.owner_account.length>0,photos:converted.size};
 }catch(e){await store.db.exec('ROLLBACK');throw e}
}
async function main(){await requireLinkedCloud();const file=resolve(process.env.LOCAL_DATABASE_PATH||resolve(root,'data/store.sqlite'));let store;try{store=await openStore();const summary=await importLocal({file,store});console.log(`Imported ${summary.products} products, ${summary.orders} orders and ${summary.photos} photos. ${summary.owner_imported?'Your existing owner login was preserved.':'Create an owner with npm run cloud:setup-admin.'} Local data was not changed.`)}finally{store?.close()}}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(()=>{console.error('Cloud import failed. Verify cloud setup, permissions, photos and that the target store is empty. Your local database was not changed.');process.exitCode=1});
