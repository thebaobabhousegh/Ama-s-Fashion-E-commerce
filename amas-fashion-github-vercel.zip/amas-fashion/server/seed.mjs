import { readFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openStore } from './commerce.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const file=resolve(process.env.DATABASE_PATH||resolve(root,'data/store.sqlite'));
await mkdir(dirname(file),{recursive:true,mode:0o700});const store=openStore(file);
try{if(store.db.prepare('SELECT COUNT(*) AS n FROM products').get().n)throw new Error('Catalogue is not empty. Refusing to replace existing products or stock.');
const products=JSON.parse(await readFile(resolve(root,'server/draft-catalogue.json'),'utf8'));for(const p of products)store.putProduct(p);console.log('Added 6 draft products with 10 SAMPLE units per size. Checkout remains controlled by environment configuration.');}finally{store.close()}
