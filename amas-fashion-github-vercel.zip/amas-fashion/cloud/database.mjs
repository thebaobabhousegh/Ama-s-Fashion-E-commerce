import { createClient } from '@libsql/client';
import { readFile } from 'node:fs/promises';
// Each request receives its own transaction context. A transaction is never shared
// between concurrent Vercel invocations, even when the underlying connection is reused.
export async function connectDatabase(url,options={}){
 const destination=url||process.env.TURSO_DATABASE_URL;
 if(!destination)throw new Error('TURSO_DATABASE_URL is required.');
 if(!options.initialize&&!/^(libsql|https):\/\//.test(destination))throw new Error('A remote libSQL database is required in Vercel.');
 const client=createClient({url:destination,authToken:process.env.TURSO_AUTH_TOKEN,intMode:'number'});let transaction=null;
 async function execute(sql,args=[]){return (transaction||client).execute({sql,args})}
 function row(result,index=0){const values=result.rows[index];return values?Object.fromEntries(result.columns.map((key,i)=>[key,values[i]])):undefined}
 const adapter={
  async initialize(){await client.executeMultiple(await readFile(new URL('./schema.sql',import.meta.url),'utf8'))},
  async exec(sql){const command=sql.trim().toUpperCase();if(command==='BEGIN IMMEDIATE'){if(transaction)throw new Error('Nested transaction rejected.');transaction=await client.transaction('write');return}if(command==='COMMIT'){const active=transaction;try{await active.commit()}finally{active.close();transaction=null}return}if(command==='ROLLBACK'){const active=transaction;try{if(active&&!active.closed)await active.rollback()}finally{active?.close();transaction=null}return}return (transaction||client).executeMultiple(sql)},
  prepare(sql){return {async get(...args){return row(await execute(sql,args))},async all(...args){const result=await execute(sql,args);return result.rows.map((_,i)=>row(result,i))},async run(...args){const result=await execute(sql,args);return {changes:result.rowsAffected,lastInsertRowid:result.lastInsertRowid}}}},
  close(){transaction?.close();transaction=null;client.close()}
 };
 return adapter;
}
